#ifndef IOT_BUS_H
#define IOT_BUS_H
#ifdef CONFIG_MT7682
#include "mtk/mt7682/mt7682_spi.h"
#endif

#endif
